-- MySQL dump 10.16  Distrib 10.1.32-MariaDB, for Linux (x86_64)
--
-- Host: mysql    Database: realxdata
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `realxdata`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `realxdata` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `realxdata`;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('64d1a01896bb');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset` (
  `id` varchar(100) NOT NULL,
  `ref` varchar(100) DEFAULT NULL,
  `portfolio` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `is_restricted` tinyint(1) DEFAULT NULL,
  `yoc` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `ix_asset_address` (`address`),
  KEY `ix_asset_city` (`city`),
  KEY `ix_asset_portfolio` (`portfolio`),
  KEY `ix_asset_ref` (`ref`),
  KEY `ix_asset_yoc` (`yoc`),
  KEY `ix_asset_zipcode` (`zipcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset`
--

LOCK TABLES `asset` WRITE;
/*!40000 ALTER TABLE `asset` DISABLE KEYS */;
INSERT INTO `asset` VALUES ('295134c1-995a-4aaa-9085-5eb4d0f38c0f','A_5','Houses','Fritz-Löffler-Straße 16',1069,'Dresden',0,1995,'2020-06-19 17:09:58','2019-02-01 00:00:00'),('7a7ffe45-7ee1-4ba2-b6da-03b593bead6e','A_3','Test Portfolio','Potsdamer Platz 3',10785,'Berlin',0,1961,'2020-06-19 17:09:57','2019-02-01 00:00:00'),('a887ac4f-06f3-45ac-acd7-47fc0bec3c99','A_2','Test Portfolio','Spreeweg 1',10557,'Berlin',1,1786,'2020-06-19 17:09:57','2019-02-01 00:00:00'),('afb360b6-698f-4294-943c-358d803b5476','A_1','Houses','Am Kupfergraben 6',10117,'Berlin',1,1876,'2020-06-19 17:09:57','2019-02-01 00:00:00'),('ce933b8c-1ded-489f-b909-497ceb57ec5e','A_4','Test Portfolio','Neuer Wall 17',20354,'Hamburg',0,2002,'2020-06-19 17:09:58','2019-02-01 00:00:00');
/*!40000 ALTER TABLE `asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `path` varchar(100) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_file_id` (`id`),
  KEY `ix_file_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` VALUES (1,'units_20190201.csv','./static/units_20190201.csv',1,'2020-06-19 17:09:57',NULL),(2,'units_20190201.csv','./static/units_20190201.csv',1,'2020-06-19 17:10:51',NULL),(3,'units_20190201.csv','./static/units_20190201.csv',1,'2020-06-19 17:11:01',NULL),(4,'units_20190201.csv','./static/units_20190201.csv',1,'2020-06-19 17:11:45',NULL);
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unit` (
  `id` varchar(100) NOT NULL,
  `ref` varchar(100) DEFAULT NULL,
  `asset_id` varchar(100) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `is_rented` tinyint(1) DEFAULT NULL,
  `rent` int(11) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `tenant` varchar(100) DEFAULT NULL,
  `lease_start` datetime DEFAULT NULL,
  `lease_end` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `asset_id` (`asset_id`),
  KEY `ix_unit_is_rented` (`is_rented`),
  KEY `ix_unit_ref` (`ref`),
  KEY `ix_unit_rent` (`rent`),
  KEY `ix_unit_size` (`size`),
  KEY `ix_unit_tenant` (`tenant`),
  CONSTRAINT `unit_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `asset` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit`
--

LOCK TABLES `unit` WRITE;
/*!40000 ALTER TABLE `unit` DISABLE KEYS */;
INSERT INTO `unit` VALUES ('14c49fc4-e431-4b31-8120-3cbb5753e43e','A_3_2','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',200,1,3000,'OFFICE','Tech GmbH','2016-01-01 00:00:00','2026-01-01 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('17bb8563-dcd9-42ad-9eee-07ffe07b14e0','A_5_5','295134c1-995a-4aaa-9085-5eb4d0f38c0f',60,0,600,'RESIDENTIAL','Stephania Sagers','2019-02-01 00:00:00','2020-02-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('215f9272-cd8c-4125-9f9d-416acbb29699','A_3_1','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',300,1,5000,'OFFICE','Tech GmbH','2016-01-01 00:00:00','2026-01-01 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('2c552712-4d26-4403-9172-7307b4f1f331','A_1_1','afb360b6-698f-4294-943c-358d803b5476',130,1,900,'RESIDENTIAL','Kelley Montufar','1990-01-01 00:00:00',NULL,'2020-06-19 17:09:57','2019-02-01 00:00:00'),('2ea14e5f-4c90-40d8-b43d-7774b5271085','A_3_3','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',300,1,6000,'OFFICE','Tech GmbH','2016-01-01 00:00:00','2026-01-01 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('32e18930-3125-4b99-984a-4e09740bb690','A_3_5','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',332,1,7000,'OFFICE','Supermarket GmbH','2018-04-01 00:00:00','2038-04-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('40ad7f04-e816-4622-af1a-66382732f7f2','A_4_4','ce933b8c-1ded-489f-b909-497ceb57ec5e',200,1,6000,'RETAIL','Suits Gmbh','2010-04-01 00:00:00','2030-04-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('4b3a6625-197f-49ee-8029-011e08572015','A_5_4','295134c1-995a-4aaa-9085-5eb4d0f38c0f',30,0,300,'RESIDENTIAL','Jackie Langsam','2019-02-01 00:00:00','2020-02-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('573100f6-025d-4ba3-80c9-c5bba924dd62','A_4_2','ce933b8c-1ded-489f-b909-497ceb57ec5e',200,1,6000,'RETAIL','Jeans GmbH','2004-06-01 00:00:00','2024-06-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('6f24d605-dcad-4b6e-bbb9-da3d8654425a','A_3_7','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',330,1,2500,'OFFICE','Trains Gmbh','2002-02-01 00:00:00','2022-02-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('870e2e54-ae23-46ce-84d4-1e35e6afa5e8','A_3_9','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',300,0,0,'OFFICE','',NULL,NULL,'2020-06-19 17:09:58','2019-02-01 00:00:00'),('8a80e52a-9841-4207-8100-beee4cde1233','A_3_8','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',400,0,0,'OFFICE','',NULL,NULL,'2020-06-19 17:09:58','2019-02-01 00:00:00'),('93ec3839-ded3-4216-a464-0ae1afb9da1c','A_2_1','a887ac4f-06f3-45ac-acd7-47fc0bec3c99',4000,1,20000,'OFFICE','Bundesrepublik GmbH','2017-03-19 00:00:00','2022-03-19 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('97b6f300-09b0-4fc0-be72-09c349435720','A_5_3','295134c1-995a-4aaa-9085-5eb4d0f38c0f',55,1,450,'RESIDENTIAL','Delmar Poissant','2018-09-01 00:00:00','2019-09-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('9c7d58dc-98a4-402d-a413-a0c678c86081','A_5_6','295134c1-995a-4aaa-9085-5eb4d0f38c0f',65,1,750,'RESIDENTIAL','Glenn Tomson','2018-09-01 00:00:00','2019-09-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('9ddb5433-751e-4740-b0af-4484f898aac5','A_5_7','295134c1-995a-4aaa-9085-5eb4d0f38c0f',39,1,300,'RESIDENTIAL','Kiyoko Pamplin','2018-09-01 00:00:00','2019-09-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('a3a85633-8019-4c0d-aebf-886abccb05e5','A_5_2','295134c1-995a-4aaa-9085-5eb4d0f38c0f',50,1,400,'RESIDENTIAL','Tabatha Ruffo','2018-09-01 00:00:00','2019-09-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('a7915e2f-4b01-4939-84d5-4422b532af5e','A_1_6','afb360b6-698f-4294-943c-358d803b5476',250,1,2500,'OFFICE','Fortune Motors GmbH','2012-01-15 00:00:00','2032-01-15 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('c042c238-dda5-4850-b58d-9a79a8245611','A_5_1','295134c1-995a-4aaa-9085-5eb4d0f38c0f',60,1,6000,'RETAIL','Suits Gmbh','2010-04-01 00:00:00','2030-04-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('c93d15e2-59eb-4765-a0c0-14a3607aed84','A_1_5','afb360b6-698f-4294-943c-358d803b5476',50,1,500,'RESIDENTIAL','Thi Millet','2016-02-01 00:00:00','2021-02-01 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('cd6bc885-a84c-4745-b53f-448ce7e77a38','A_3_6','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',123,1,4030,'OFFICE','Supermarket GmbH','2018-04-01 00:00:00','2038-04-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('cdc373ab-b7de-4d3a-b546-d4e2e9c7eb9a','A_2_1','a887ac4f-06f3-45ac-acd7-47fc0bec3c99',400,1,4000,'RESIDENTIAL','Frank-Walter Steinmeier','2017-03-19 00:00:00','2022-03-19 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('d6e07d3c-6eef-43d2-8973-d5db28387013','A_1_4','afb360b6-698f-4294-943c-358d803b5476',95,1,1000,'RESIDENTIAL','Ismael Desjardins','2019-02-01 00:00:00','2024-02-01 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('d90a42ff-67ea-48da-9911-e7ccb3bb5d6e','A_4_1','ce933b8c-1ded-489f-b909-497ceb57ec5e',200,1,6000,'RETAIL','Hats GmbH','2004-06-01 00:00:00','2034-06-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('d915830f-45ca-4d14-978b-6f4ec085b4a2','A_3_4','7a7ffe45-7ee1-4ba2-b6da-03b593bead6e',220,1,5300,'OFFICE','Tech GmbH','2016-01-01 00:00:00','2026-01-01 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('e3968b18-4c40-4a07-8cbb-5e1d45818ebf','A_1_3','afb360b6-698f-4294-943c-358d803b5476',90,1,1200,'RESIDENTIAL','Rebbecca Delatorre','2017-03-01 00:00:00','2027-03-01 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00'),('e39dbacc-e5e8-4247-9cc2-9a25bfa4ab00','A_4_3','ce933b8c-1ded-489f-b909-497ceb57ec5e',200,1,6000,'RETAIL','Shirts GmbH','2015-02-15 00:00:00','2025-02-15 00:00:00','2020-06-19 17:09:58','2019-02-01 00:00:00'),('ff347ff3-94eb-4b98-9b91-50ab78c976e2','A_1_2','afb360b6-698f-4294-943c-358d803b5476',130,1,1500,'RESIDENTIAL','Katelyn Mattern','2000-04-01 00:00:00','2020-04-01 00:00:00','2020-06-19 17:09:57','2019-02-01 00:00:00');
/*!40000 ALTER TABLE `unit` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-19 18:25:00
